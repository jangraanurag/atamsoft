<?php $__env->startSection('title', 'Create New Order | Buyer Dashboard'); ?>
<?php $__env->startSection('content'); ?>


  <!-- Main -->
  <main class="flex-grow p-6">
    <div class="bg-white rounded-xl shadow p-6 max-w-5xl mx-auto">
      <h2 class="text-2xl font-semibold text-gray-800 mb-6">Create New Order</h2>
      <form method="POST" action="<?php echo e(route('order.create')); ?>" enctype="multipart/form-data" class="grid grid-cols-1 md:grid-cols-2 gap-6">

        <!-- Select Dropdowns -->
        <div>
          <label>Brand</label>
          <select name="order_brand" required class="w-full border rounded p-2"><option value="">Select</option></select>
        </div>
        <div>
          <label>Product Name</label>
          <select name="order_productName" required class="w-full border rounded p-2"><option value="">Select</option></select>
        </div>
        <div>
          <label>Label Type</label>
          <select name="order_labelType" required class="w-full border rounded p-2"><option value="">Select</option></select>
        </div>
        <div>
          <label>Unit</label>
          <select name="order_unit" class="w-full border rounded p-2"><option value="">Select</option></select>
        </div>
        <div>
          <label>Dimension Unit</label>
          <select name="order_d_unit" class="w-full border rounded p-2"><option value="">Select</option></select>
        </div>
        <div>
          <label>Status</label>
          <select name="order_status" required class="w-full border rounded p-2"><option value="">Select</option></select>
        </div>
        <div>
          <label>Buyer</label>
          <select name="order_buyer" required class="w-full border rounded p-2"><option value="">Select</option></select>
        </div>
        <div>
          <label>Ship Via</label>
          <select name="order_shipvia" class="w-full border rounded p-2"><option value="">Select</option></select>
        </div>
        <div>
          <label>Color Set</label>
          <select name="order_colorset" class="w-full border rounded p-2"><option value="">Select</option></select>
        </div>

        <!-- Input Fields -->
        <div><label>Weight</label><input type="number" step="0.01" name="order_weight" class="w-full border rounded p-2"></div>
        <div><label>Quantity</label><input type="number" step="0.01" name="order_qty" class="w-full border rounded p-2"></div>
        <div><label>Manufactured Qty</label><input type="number" step="0.01" name="order_manufacturedqty" class="w-full border rounded p-2"></div>
        <div><label>Length</label><input type="number" step="0.01" name="order_length" class="w-full border rounded p-2"></div>
        <div><label>Width</label><input type="number" step="0.01" name="order_width" class="w-full border rounded p-2"></div>
        <div><label>Order Date</label><input type="date" name="order_date" class="w-full border rounded p-2"></div>
        <div><label>Delivery Date</label><input type="date" name="order_deliverydate" class="w-full border rounded p-2"></div>
        <div><label>Price</label><input type="number" step="0.01" name="order_price" class="w-full border rounded p-2"></div>
        <div><label>Mould Price</label><input type="number" step="0.01" name="order_mouldprice" class="w-full border rounded p-2"></div>
        <div><label>Shipment No</label><input type="text" name="order_shipmentno" class="w-full border rounded p-2"></div>
        <div><label>Salesman</label><input type="text" name="order_salesman" class="w-full border rounded p-2"></div>
        <div><label>Die Set</label><input type="number" name="order_dieset" class="w-full border rounded p-2"></div>
        <div><label>Logo</label><input type="number" name="order_logo" class="w-full border rounded p-2"></div>
        <div><label>Nail Material</label><input type="text" name="order_nailmaterial" class="w-full border rounded p-2"></div>

        <!-- File Uploads -->
        <div><label>Order Image</label><input type="file" name="order_image" accept=".jpg,.png,.jpeg" class="w-full border rounded p-2"></div>
        <div><label>CDR File</label><input type="file" name="order_cdr" accept=".cdr" class="w-full border rounded p-2"></div>
        <div><label>Purchase Order (PO)</label><input type="file" name="order_po" accept=".pdf,.jpg,.png" class="w-full border rounded p-2"></div>

        <!-- Remarks -->
        <div class="md:col-span-2">
          <label>Remark</label>
          <textarea name="order_remark" rows="3" class="w-full border rounded p-2"></textarea>
        </div>

        <!-- Submit -->
        <div class="md:col-span-2 text-right">
          <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">Submit Order</button>
        </div>

      </form>
    </div>
  </main>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/jangraanurag/sites/atamsoft/resources/views/order/create.blade.php ENDPATH**/ ?>