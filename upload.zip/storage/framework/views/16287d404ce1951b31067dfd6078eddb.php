<?php $__env->startSection('title', 'Create Shipper'); ?>

<?php $__env->startSection('content'); ?>
<main class="flex-grow p-6">
  <div class="bg-white rounded-xl shadow p-6 max-w-3xl mx-auto">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">Create New Shipper</h2>

    <form method="POST" action="<?php echo e(route('shipper.store')); ?>" class="space-y-6">
      <?php echo csrf_field(); ?>

      <!-- Shipper Name -->
      <div>
        <label for="shipper_name" class="block text-sm font-medium text-gray-700">Shipper Name</label>
        <input type="text" id="shipper_name" name="shipper_name" maxlength="20" required class="mt-1 w-full border rounded px-3 py-2" />
      </div>

      <!-- Submit Button -->
      <div class="text-right">
        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">Save Shipper</button>
      </div>
    </form>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/jangraanurag/sites/atamsoft/resources/views/shipper/create.blade.php ENDPATH**/ ?>