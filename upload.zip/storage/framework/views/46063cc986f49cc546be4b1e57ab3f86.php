<?php $__env->startSection('title', 'Buyer Dashboard'); ?>
<?php $__env->startSection('content'); ?>

  <!-- Main Content -->
  <main class="flex-grow p-6">
    <div class="bg-white rounded-xl shadow p-6 max-w-3xl mx-auto">
      <h2 class="text-2xl font-semibold text-gray-800 mb-6">Create New Product</h2>

      <form method="POST" action="<?php echo e(route('products.store')); ?>" class="space-y-6">
         <?php echo csrf_field(); ?>

        <!-- Product Name -->
        <div>
          <label for="product_name" class="block text-sm font-medium text-gray-700">Product Name</label>
          <input type="text" id="product_name" name="product_name" maxlength="100" required class="mt-1 w-full border rounded px-3 py-2" />
        </div>



        <!-- Submit Button -->
        <div class="text-right">
          <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">Save Product</button>
        </div>
      </form>
    </div>
  </main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/jangraanurag/sites/atamsoft/resources/views/products/create.blade.php ENDPATH**/ ?>