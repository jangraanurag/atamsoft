<?php $__env->startSection('title', 'Edit Order Status'); ?>

<?php $__env->startSection('content'); ?>
<main class="flex-grow p-6">
  <div class="bg-white rounded-xl shadow p-6 max-w-3xl mx-auto">
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">Edit Order Status</h2>

    <form method="POST" action="<?php echo e(route('status.update', $status->id)); ?>" class="space-y-6">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>

      <!-- Status Name -->
      <div>
        <label for="status_name" class="block text-sm font-medium text-gray-700">Status Name</label>
        <input type="text" id="status_name" name="status_name" value="<?php echo e(old('status_name', $status->status_name)); ?>" maxlength="20" required class="mt-1 w-full border rounded px-3 py-2" />
      </div>

      <!-- Submit Button -->
      <div class="text-right">
        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">Update Status</button>
      </div>
    </form>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/jangraanurag/sites/atamsoft/resources/views/status/edit.blade.php ENDPATH**/ ?>