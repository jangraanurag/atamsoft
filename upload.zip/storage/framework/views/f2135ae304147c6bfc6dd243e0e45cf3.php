<?php $__env->startSection('title', 'Label Type List'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Main Content -->
  <main class="flex-grow p-6">
    <div class="bg-white rounded-xl shadow p-6 max-w-3xl mx-auto">
      <h2 class="text-2xl font-semibold text-gray-800 mb-6">Label Type List</h2>

      <div class="mb-4 text-right">
        <a href="<?php echo e(route('labeltype.create')); ?>" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Add New Label Type</a>
      </div>

      <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
          <span class="block sm:inline"><?php echo e(session('success')); ?></span>
        </div>
      <?php endif; ?>

      <div class="overflow-x-auto">
        <table class="min-w-full bg-white">
          <thead>
            <tr>
              <th class="py-2 px-4 border-b text-left">Label Type</th>
              <th class="py-2 px-4 border-b text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $labeltypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labeltype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td class="py-2 px-4 border-b"><?php echo e($labeltype->labeltype_name); ?></td>
                <td class="py-2 px-4 border-b text-center">
                  <a href="<?php echo e(route('labeltype.edit', $labeltype->id)); ?>" class="text-blue-600 hover:text-blue-900 mr-2">Edit</a>
                  <form action="<?php echo e(route('labeltype.destroy', $labeltype->id)); ?>" method="POST" class="inline-block" onsubmit="return confirm('Are you sure you want to delete this label type?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="text-red-600 hover:text-red-90">Delete</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="2" class="py-4 px-4 text-center text-gray-500">No label types found.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/jangraanurag/sites/atamsoft/resources/views/labeltype/index.blade.php ENDPATH**/ ?>