<?php $__env->startSection('title', 'Edit Label Type'); ?>
<?php $__env->startSection('content'); ?>
  <!-- Main Content -->
  <main class="flex-grow p-6">
    <div class="bg-white rounded-xl shadow p-6 max-w-3xl mx-auto">
      <h2 class="text-2xl font-semibold text-gray-800 mb-6">Edit Label Type</h2>
<?php if($errors->any()): ?>
    <div class="mb-4 p-4 bg-red-100 border border-red-300 text-red-700 rounded">
        <strong>There were some errors with your submission:</strong>
        <ul class="list-disc pl-5 mt-2">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

<?php endif; ?>
      <form method="POST" action="<?php echo e(route('labeltype.update', ['id' => $labelType->id])); ?>" class="space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Label Type Name -->
        <div>
          <label for="labeltype_name" class="block text-sm font-medium text-gray-700">Label Type</label>
          <input type="text" id="labeltype_name" name="labeltype_name" maxlength="50" value="<?php echo e(old('labeltype_name', $labelType->labeltype_name)); ?>" required class="mt-1 w-full border rounded px-3 py-2" />
        </div>

        <!-- Submit Button -->
        <div class="text-right">
          <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">Update</button>
        </div>
      </form>
    </div>
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/jangraanurag/sites/atamsoft/resources/views/labeltype/edit.blade.php ENDPATH**/ ?>